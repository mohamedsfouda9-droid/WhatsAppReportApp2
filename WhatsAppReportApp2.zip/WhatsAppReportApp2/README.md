# WhatsAppReportApp2

تطبيق Android بسيط بواجهة عربية لإعداد رسالة مراجعة يدوية تتضمن رقم هاتف واتساب وسبب البلاغ. لا يرسل التطبيق أي بلاغ تلقائيًا؛ بل يفتح تطبيق البريد برسالة مسودة يراجعها المستخدم ويرسلها بنفسه.

## المتطلبات
- Android Studio حديث
- JDK 17
- Android SDK Platform 35

## البناء محليًا
افتح المشروع في Android Studio، ثم اختر **Build > Build APK(s)**.
يمكن أيضًا البناء من بيئة فيها Gradle 8.9 وAndroid SDK 35:

```bash
gradle assembleDebug
```

ملف APK الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
عند الدفع إلى GitHub أو تشغيل workflow يدويًا، ينشئ الملف `.github/workflows/android.yml` نسخة Debug APK ويرفعها كـ artifact.

## ملاحظات
- حقل المستلم في البريد متروك للمستخدم كي يختار جهة الاتصال الرسمية المناسبة ويتأكد من صحة العنوان.
- لا يتصل التطبيق بواتساب ولا يتحقق من الرقم ولا يرسل بلاغات تلقائيًا.
