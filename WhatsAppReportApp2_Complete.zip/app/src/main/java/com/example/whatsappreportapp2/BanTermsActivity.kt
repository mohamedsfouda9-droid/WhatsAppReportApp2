package com.example.whatsappreportapp2

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class BanTermsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ban_terms)

        val termsMap = mapOf(
            R.id.btn_term_1 to """
                انتهاك🥵𒀱⃢انتهاك🥵𒀱⃢انتهاك🥵𒀱انتهاك🥵⃢⃢⃢⃠⃤𒀱⃠⃤𒀱⃠انتهاك🥵𒀱⃢𒀱⃢انتهاك𒀱⃢انتهاك👿⃢⃢⃠𒀱⃠𒀱⃢𒀱⃢𒀱⃢⃢⃢⃠⃤𒀱⃠انتهاك⃤𒀱⃠𒀱⃢𒀱⃢انتهاك👿𒀱⃢⃢⃢⃠⃤𒀱⃠⃤𒀱⃠𒀱⃢𒀱⃢𒀱⃢⃢⃢⃠𒀱⃠𒀱⃢𒀱⃢𒀱⃢⃢⃢⃠⃤انتهاك👿𒀱⃠⃤aNThak2'👿𒀱⃠𒀱⃢.
                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_2 to """
                ثغرة الباند الجديد حظر أرقام واتساب

                🦅بريد الشركة➪

                support@support.whatsapp.com
                android@support.whatsapp.com
                smb@support.whatsapp.com
                jan@whatsapp.com
                android@whatsapp.com
                press@whatsapp.com
                android_web@support.whatsapp.com

                الموضوع ▽▽

                سؤال حول واتساب على Android


                الرساله اللإكترونيه
                Please disable my number temporarily because I changed my phone number and I want to close my old number, this is my number +967777777777

                ✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌👿
                https://t.me/learn_h_ack
            """,

            R.id.btn_term_3 to """
                ꫟꫟꫟ثغره طرد وتشريد الارقام من الواتساب مقدمه من꫟꫟꫟
                ا̶ل̶ك̶ا̶س̶ر̶ ا̶ل̶م̶ح̶ت̶ر̶ف̶...👿 

                ꫟꫟꫟جيميلات الشركه ꫟꫟꫟

                support@support.whatsapp.com
                smb@support.whatsapp.com


                ꫟꫟꫟الموضوع ꫟꫟꫟

                الرجاء تعطيل رقمي او حظره لانني قمت بتحميل واتساب معدل غير الرسمي

                ꫟꫟꫟ثغره الحظر꫟꫟꫟

                السلام عليكم فريق دعم واتساب هناك حاله طوارئ بخصوص رقمي اريد منكم تعطيل رقم هاتفي او حظره من الواتساب لانني وقعت في الفخ قمت بتحميل واتساب من مصادر اخرى غير الرسمي وقمت بتحميل واتساب معدل وانا الان لا استطيع ان انقل رقمي الى واتساب الرسمي لانه عالق في النسخه المعدله الرجاء منكم حظر رقم هاتفي لكي استخرج رقمي من الواتساب المعدل واعيده مره اخرى الى الواتساب الرسمي من مصادر موثوقه او جوجل بلاي انا ارجو منكم تعطيله او حظره باسرع وقت ممكن هذا هو رقم هاتفي الذي اريد حظره من واتساب
                967777777777+

                مــــقــدم الــــثـــغــره 
                ✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌👿
                https://t.me/learn_h_ack
            """,

            R.id.btn_term_4 to """
                Bonjour l équipe d assistance de WhatsApp" a quelqu un qui télécharge des clips et des photos pornographiques et les envoie à des personnes et travaille à violer les conditions d utilisation de WhatsApp "et agace les gens en envoyant ces clips et photos pornographiques" veuillez l équipe d assistance تعطيل désactiver le compte de cette personne" ceci est le numéro de cette personne (+20) avec toutes mes salutations à l équipe d assistance WhatsApp" et merci

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_5 to """
                FSXS instgram هذا الحساب مخصص لنشر صور جنسية ومحتوى إباحي وسلوك غير أخلاقي بين أفراد المجتمع في حساب instgram FSXS هذا الحساب مخصص لنشر الصور الجنسية والمحتوى الإباحي والفجور بين أفراد المجتمع من سلوك هذا الحساب وهذا هوا رقمه :+2

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_6 to """
                ايميلات الشركه▽▽▽

                android@support.whatsapp.com
                android_web@support.whatsapp.com
                support@support.whatsapp.com
                android@whatsapp.com
                press@whatsapp.com
                jan@whatsapp.com

                الموضوع ياحب ▽▽▽

                Stop sending my phone number code


                الرساله اللإكتروني▽▽▽

                Hello, WhatsApp support team, please stop sending the verification code to my number because it was stolen and I can t get the contact card back. My number is (+967777777777) Thank you, support team, and thank you very much

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_7 to """
                Здравствуйте, служба поддержки WhatsApp! Я надеюсь, что у вас всё хорошо. Я просто хочу сообщить вам о человеке, который отправляет неприемлемые сообщения, нарушает мою конфиденциальность и правила конфиденциальности WhatsApp. Я надеюсь, что вы отнесетесь к этому с пониманием, решите эту проблему как можно скорее و примете меры в отношении этого человека, который нарушает правила. Вот номер нарушителя конфиденциальности: +967777777777. Спасибо вам, команда поддержки и помощи, за сотрудничество с нами.

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_8 to """
                🥵WhatsApp has been updated:🥵🔥
                Do you want to earn money through whatsapp.com?🔞⁉️
                Earn $1 Need help?- Click
                On the contact information below for 1 second to get 💰$1 credit
                Be active with the connection and repeat the connection more than 90% in 1 hours because our systems will assume that you are fake. Be logged into the account for several different
                Ciao azienda WhatsApp. Sosteniamo il sito pornografico e sosteniamo il terrorismo nel distruggere l organizzazione governativa americana, e questo non avviene in alcun modo. Distruggeremo il sito web del signor Presidente degli Stati Uniti e distruggeremo WhatsApp azienda. Amiamo la corruzione tra le persone. minutes and repeat the connection in the process again
                Please read the conditions to get the coins.
                🔥 🥵• Your available balance: 🥵🔥$100
                BitRX invites you to join the (BTC) internal discussion group where investment experts post daily how to make 🥵🔥$1000-5000 in the cryptocurrency market. click to enter
                call us👇👇👇👇👇👇👇👇👇👇
                https://api.whatsapp.com/send?phone=+2010

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_9 to """
                ▓⃟▓⃟▒⃟▒⃟▓⃟▒⃟▓⃟⃟▒⃟░⃟▓⃟⃟⃟▒⃟░⃟⃟⃟ᚏᚏᚏᚏ⃠⃠⃠⃠▓⃟▓⃟▒⃟▒⃟▓⃟▒⃟▓⃟⃟▒⃟░⃟▓⃟⃟⃟▒⃟░⃟⃟⃟ᚏᚏᚏᚏ⃠⃠⃠⃠⃟⃟⃠⃠⃟⃠⃠⃠⃝⃝⃟⃠⃠⃞꙰҉⃝꙲𐅮𐅮⃟𐅮⃟҉҉⨻🇸🇾☒☓﹡⃝꙱꙲꙲꙲꙲🇸🇾⃤⃝⃞⃟⃠꙲⃝҉҈҈꙲𐅮⁙፨𖤓⃤⃤⃤⃤⃤⃤⃝⃞⃞⃟⃟⃠⃠๖ۣۣۜG𓃑𓃑𓃑ﷻ⃞⃞⃟⃞꙲?🇸🇾?🇾⃟⃠⃠⁜𖤓⃤꙰⃤҈҉𝓇𝓈𝓈𝓈𝓇𝓇⃝⃞⃟⃟⃠⃠⃟⃝⃝꙰꙰꙰꙱꙱҉🇸🇾♐⃤⃤҈҈꙰꙰꙰⃝꙰꙱꙱⃞⃝҉꙰҈҉꙰

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_𝒦_𝒜_ℳ_ℴ_¥❌
            """,

            R.id.btn_term_10 to """
                ꧁𖡹⃢𖣔♝̤֟®V₸ҤE🌏♝̤𖣔⃢𖡹꧂        🇸🇬⃞⃟⃞⃟⃤⃝𝘈𝘙𝘙𝘜𝘔𝘓𝘖𝘝𝘌⃞⃟⃤⃝🇲🇾 🏴‍☠️⃟𝗣𝗔͙𝗧͙𝗥͙𝗜𝅦͙𝗢͙𝗧͙𝗔͙𝗦⃟ ͙𒆖PÏŘÆŤÆ§🏴‍☠️VÏŘŰ§☠️🌞 🐉⃟̷𝐄̷𝐕͢𝐈𝐋•𝐌͢𝐀𝐊𝐄𝐑•𝐎͢𝐅𝐂⃟🐉̷ ✘͢͢ۦོ͢⇣͢✰͢↬ÂмRØ^^O̷ ꦿ⃕O̷↬ۦོ͢✰͢⇣

                المصدر :✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_ℋ_𝒜_ℳ_ℴ_¥❌
            """
        )

        for ((buttonId, termText) in termsMap) {
            val button = findViewById<Button>(buttonId)
            button?.setOnClickListener {
                copyToClipboard(termText)
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("BanTerm", text)
        clipboard.setPrimaryClip(clip)

        Toast.makeText(this, "اتنسخ يروحي 😉✨", Toast.LENGTH_SHORT).show()
    }
}
