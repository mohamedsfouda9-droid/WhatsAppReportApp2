package com.example.whatsappreportapp2;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(13, 35, 90); // #0D235A
    private static final int WHITE = Color.WHITE;
    private EditText phoneInput;
    private EditText reasonInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        try {
            BitmapDrawable wallpaper = new BitmapDrawable(getResources(), BitmapFactory.decodeResource(getResources(), R.drawable.demon_king_bg));
            wallpaper.setGravity(Gravity.FILL);
            scroll.setBackground(wallpaper);
        } catch (Exception ignored) {
            scroll.setBackgroundColor(NAVY);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(24));
        root.setGravity(Gravity.TOP);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("طلب مراجعة حساب واتساب");
        title.setTextColor(WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("جهّز رسالة للمراجعة ثم راجعها وأرسلها بنفسك عبر البريد الإلكتروني.");
        subtitle.setTextColor(Color.rgb(220, 228, 248));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(12), 0, dp(28));
        root.addView(subtitle, matchWrap());

        addLabel(root, "رقم هاتف واتساب (مع مفتاح الدولة)");
        phoneInput = new EditText(this);
        phoneInput.setSingleLine(true);
        phoneInput.setHint("+20XXXXXXXXXX");
        phoneInput.setTextColor(WHITE);
        phoneInput.setHintTextColor(Color.rgb(175, 190, 225));
        phoneInput.setTextSize(16);
        phoneInput.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        styleInput(phoneInput);
        LinearLayout.LayoutParams phoneParams = matchWrap();
        phoneParams.bottomMargin = dp(20);
        root.addView(phoneInput, phoneParams);

        addLabel(root, "سبب طلب المراجعة");
        reasonInput = new EditText(this);
        reasonInput.setMinLines(4);
        reasonInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        reasonInput.setHint("اكتب سبب طلب المراجعة بوضوح...");
        reasonInput.setTextColor(WHITE);
        reasonInput.setHintTextColor(Color.rgb(175, 190, 225));
        reasonInput.setTextSize(16);
        reasonInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        styleInput(reasonInput);
        LinearLayout.LayoutParams reasonParams = matchWrap();
        reasonParams.bottomMargin = dp(24);
        root.addView(reasonInput, reasonParams);

        Button emailButton = new Button(this);
        emailButton.setText("فتح البريد وتجهيز الرسالة");
        emailButton.setTextSize(16);
        emailButton.setAllCaps(false);
        emailButton.setTextColor(NAVY);
        emailButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(WHITE));
        root.addView(emailButton, matchWrap());
        emailButton.setOnClickListener(v -> openEmailDraft());

        TextView note = new TextView(this);
        note.setText("تنبيه: لا يرسل التطبيق البلاغ تلقائيًا. راجع المعلومات واختر جهة الاتصال الرسمية المناسبة قبل الإرسال.");
        note.setTextColor(Color.rgb(220, 228, 248));
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(22), 0, 0);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private void openEmailDraft() {
        String phone = phoneInput.getText().toString().trim();
        String reason = reasonInput.getText().toString().trim();

        if (TextUtils.isEmpty(phone)) {
            phoneInput.setError("أدخل رقم الهاتف");
            phoneInput.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(reason)) {
            reasonInput.setError("اكتب سبب طلب المراجعة");
            reasonInput.requestFocus();
            return;
        }

        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(reasonInput.getWindowToken(), 0);

            String subject = "طلب مراجعة بخصوص حساب واتساب";
            String body = "مرحبًا،\n\nأرجو مراجعة الحالة التالية:\n"
                    + "رقم الهاتف: " + phone + "\n"
                    + "سبب طلب المراجعة: " + reason + "\n\n"
                    + "أرجو التحقق من المعلومات واتخاذ الإجراء المناسب وفقًا للسياسات المعمول بها.\n\n"
                    + "شكرًا لكم.";

            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);
            intent.putExtra(Intent.EXTRA_TEXT, body);
            startActivity(Intent.createChooser(intent, "اختر تطبيق البريد"));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "لا يوجد تطبيق بريد مثبت على الجهاز.", Toast.LENGTH_LONG).show();
        }
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(WHITE);
        label.setTextSize(15);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = dp(8);
        root.addView(label, params);
    }

    private void styleInput(EditText editText) {
        editText.setPadding(dp(14), dp(12), dp(14), dp(12));
        editText.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                Color.rgb(185, 201, 239)));
        editText.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
